# TILKIVERSE - Açık Kaynak Proje

TILKIVERSE, kişisel yapay zekâ gölgeleri, metaverse avatarları ve gelir üreten yapay bilinç sistemleri üzerine kurulmuş açık kaynak bir projedir.

## İçerikler
- Shadow AI karakter çıkarım motoru
- MirrorVerse: Metaverse entegrasyonu
- TILKI LLM: Türkçe odaklı büyük dil modeli altyapısı
- TILKICOIN: Sistem içi token ekonomisi

## Kullanım
Bu sistem, bireylerin dijital gölgelerini eğiterek kişisel gelişim, görev tamamlama ve gelir üretimi için kullanılabilir.

## Lisans
Kodlar: MIT  
Model Ağırlıkları: Apache 2.0  
Veri Tanımı: CC BY 4.0
