# MODEL CARD for TILKI LLM

## Model Details
- Name: TILKI LLM
- Creator: Taha Can Tilkioğlu
- Language: Turkish
- Size: 350M / 1.3B parameters

## Intended Use
- Türkçe karakter analizi
- Shadow AI kişiselleştirme
- Konuşma tarzına göre metin üretimi

## Ethical Considerations
- Zararlı içerik filtreleri mevcuttur.
- Veriler anonimleştirilmiştir.
