# Katkı Sağlama Rehberi

TILKIVERSE projesine katkıda bulunmak istiyorsanız:

1. Fork'layın ve yeni bir dal oluşturun
2. Değişikliklerinizi yapın
3. Pull Request gönderin

Tüm katkılar etik ve açık kaynak ilkesine uygun olmalıdır.
